#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>


int create_softlink(const char *, const char *);

