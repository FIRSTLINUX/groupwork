#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

int content_main(int,char *,char *,char*);

